# -*- coding: utf-8 -*-
from django.utils.version import get_version

VERSION = (4, 1, 0, "final", 0)

__version__ = get_version(VERSION)
